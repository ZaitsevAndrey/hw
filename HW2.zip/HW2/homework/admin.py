from django.contrib import admin
from homework import models

admin.site.register(models.Good)
admin.site.register(models.Comment)